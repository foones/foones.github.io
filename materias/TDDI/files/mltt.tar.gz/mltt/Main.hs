import System.Environment(getProgName, getArgs)

import Parser(tokenize, parseProgram)
import Pprint(pprintProgram)
import Checker(checkProgram)

main :: IO ()
main = do
  args <- getArgs
  run args

run :: [String] -> IO ()
run [filename] = do
  source <- readFile filename
  checkProgram . parseProgram . tokenize $ source
  return ()
run _ = do
  progName <- getProgName
  putStrLn "Uso:"
  putStrLn ("  " ++ progName ++ " <archivo>")

