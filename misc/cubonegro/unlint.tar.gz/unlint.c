/*
**  Copyright (c) 2003, Pablo Barenbaum
**  <pablob@starlinux.net>
**
**  This program is free software; you can redistribute it and/or modify
**  it under the terms of the GNU General Public License as published by
**  the Free Software Foundation; either version 2 of the License, or
**  (at your option) any later version.
**
**  This program is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU General Public License for more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program; if not, write to the Free Software
**  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/*
** A quick and dirty Unlambda interpreter.
** The code isn't very reusable, but it's easily extensible.
*/
#include <stdio.h>
#include <stdlib.h>
#include "gc.h"

/* An Unlambda Function has one of these types */
typedef enum {
	typeNil = 0, typeBackquote,
	typeI,				/* Identity */
	typeV,				/* Void */
	/* The two stages of currying K */
	typeK1,				/* Constant function generator */
	typeK2,				/* Constant function */
	/* The three stages of currying S */
	typeS1,				/* Substitution */
	typeS2,				/* Substitution first partial */
	typeS3,				/* Substitution application */
	typeD,				/* Delay */
	typePromise,			/* Promise */
	typeC,				/* Call/cc */
	typeContinuation,		/* The continuation function itself */
	typeDot,			/* Print */
	typeE,				/* Exit */
	typeRead,			/* Read character */
	typeCompare,			/* Compare character read */
	typeReprint,			/* Reprint character read */
} Type;

/*
** Every Unlambda function has: 1) a type; and 2) associated data
** (e.g., .x is typeDot and has car = 'x'; the function that the
** evaluation of ''s.xi yields is typeS3 and has as args[0] the
** function .x and as args[1] the function i)
*/
typedef struct _funktion {
	Type type;
	union {
		struct _funktion *args[2];
		char car;
		struct _stack *promised_code;
		struct _continuation *cont;
	} data;
} Funktion;

/* A stack containing functions or numbers */
typedef struct _stack {
	union {
		Funktion *f;
		unsigned int n;
	} value;
	struct _stack *next;
} Stack;

/* The continuation object type */
typedef struct _continuation {
	Stack *main_stack, *operator_stack, *applications_remaining;
	unsigned int stacked;
	char current_character;
} Continuation;

#define FUNVAL(STACK)	(STACK)->value.f
#define NEXT(STACK)	(STACK)->next

/* XXX: Garbage collection relies on Hans Boehm's GC.
** I'm too lazy (not in the Haskell sense) to implement
** reference count.
** If you want to use the interpreter without garbage
** collection just replace GC_malloc with malloc in the
** following line. (Notice that no memory will be ever freed).
*/
#define NEW(OBJ,TYPE)	if (!(OBJ = (TYPE *) GC_malloc(sizeof(TYPE)))) die(errMemory);

/* Some global objects. */

Stack *Main_Stack;

/* These are always the same, as they don't have data
** in their closures.
*/
Funktion Nil = { typeNil };
/* Backquote is not a function but anyway stored in the
** stack as if it were.
*/
Funktion Backquote = { typeBackquote };
Funktion S_function = { typeS1 };
Funktion K_function = { typeK1 };
Funktion I_function = { typeI };
Funktion V_function = { typeV };
Funktion D_function = { typeD };
Funktion C_function = { typeC };
Funktion R_function = { typeDot };	/* R's data initialized in init() */
Funktion E_function = { typeE };
Funktion AT_function = { typeRead };
Funktion PIPE_function = { typeReprint };

#define NIL (&Nil)
#define BACKQUOTE (&Backquote)
#define S_FUNCTION (&S_function)
#define K_FUNCTION (&K_function)
#define I_FUNCTION (&I_function)
#define V_FUNCTION (&V_function)
#define D_FUNCTION (&D_function)
#define C_FUNCTION (&C_function)
#define R_FUNCTION (&R_function)
#define E_FUNCTION (&E_function)
#define AT_FUNCTION (&AT_function)
#define PIPE_FUNCTION (&PIPE_function)

/* Error "handling" (this isn't handling...) */
enum { errMemory = 1, errEOF, errChar, errArgs, errOpen, errClose, errInternal };

void
die(int errno)
{
	char *errmsg[] = {
		"",
		"Out of memory",
		"Unexpected end of file",
		"Character not recognized",
		"Expected zero or one arguments",
		"Cannot open input file",
		"Cannot close input file",
		"Internal error",
	};
	fprintf(stderr, "Error %i: %s\n", errno, errmsg[errno]);
	exit(errno);
}

/*
** Some macros and functions to handle the stack
*/

#define STACK_NEW()		stack_new(NIL,0)
#define PUSH(ST,V)		ST = stack_new(V, ST)
#define POP(ST)			stack_pop(&(ST))
#define APPEND(LAST,FUN)	FUNVAL(LAST) = FUN;\
				NEXT(LAST) = STACK_NEW();\
				LAST = NEXT(LAST);

Stack *
stack_new(v, n)
	Funktion *v;
	Stack *n;
{
	Stack *p;
	
   	NEW(p, Stack);
	FUNVAL(p) = v;
	NEXT(p) = n;
	return p;
}

Funktion *
stack_pop(Stack **stack)
{
	Funktion *f;
	
	if ( *stack == 0 ) return NIL;
	f = FUNVAL(*stack);
	*stack = NEXT(*stack);
	return f;
}

/*
** Function constructors
*/

Funktion *
funktion_new(Type type, Funktion *arg1, Funktion *arg2)
{
	Funktion *f;

	NEW(f, Funktion);
	f->type = type;
	f->data.args[0] = arg1;
	f->data.args[1] = arg2;
	return f;
}

Funktion *
car_funktion_new(Type type, char car)
{
	Funktion *f;

	NEW(f, Funktion);
	f->type = type;
	f->data.car = car;
	return f;
}

/* If the first element is a backquote, pop it and do the body. */
#define IF_BACKQUOTE(BODY) \
	if ( FUNVAL(Main_Stack) == BACKQUOTE ) {\
		POP( Main_Stack );\
		BODY;\
	}

/*
** APPLY (with implicit eval)
** Not quite nice. Abuse of goto is made; but that means 
** heap sized recursion and gain on speed.
*/

/* Macros to use a stack for storing numbers instead of functions. */
#define VAL(STACK)	STACK->value.n
#define SET(STACK,N)	STACK->value.n = N
#define INC(STACK,N)	SET(STACK, VAL(STACK) + N)
/*
** Pops two functions and applies the former to
** the latter
*/
void
apply(void)
{
	/* XXX: it might be nice declaring some of these as register */
	Stack *operator_stack = STACK_NEW();
	Stack *applications_remaining = STACK_NEW();
	unsigned int stacked = 1;
	char current_character = EOF;
	Funktion *rator, *rand;

	PUSH(applications_remaining, STACK_NEW());
	SET(applications_remaining, 0);

begin_apply:
	/* Get the operator */
	IF_BACKQUOTE (
		INC(applications_remaining, 1);
		goto begin_apply;
	);
	rator = POP( Main_Stack );
	/**/
	
	/* Special form : D */
	/*
	** XXX: While handling promises, the promised code is copied.
	** That's both space and time inefficient, but the original code
	** shouldn't be changed. That way, call/cc can just reference
	** the Main_Stack, without copying it.
	*/
	if ( rator == D_FUNCTION ) {
		/*
		** If the operator is the D function,
		** we don't want the operand to be evaluated.
		** Instead, a promise function is created
		** and pushed.
		*/
		unsigned int count = 1;
		Stack *p, *last = STACK_NEW();
		Funktion *promise;

		NEW(promise, Funktion);
		promise->type = typePromise;

		/* promised_code points to the beginning of the promised data. */
		promise->data.promised_code = last;
		/* Look for the end */
		for ( p = Main_Stack; count; p = NEXT(p) ) {
			APPEND( last, FUNVAL(p) );
			if ( FUNVAL(p) == BACKQUOTE )
				count++;
			else
				count--;
		}

		/*
		** Now the main stack is the promise plus the rest
		** of the stack.
		*/
		Main_Stack = stack_new(promise, p);
		goto end_apply;
	}
	/**/
	
	/* Get the operand */
	IF_BACKQUOTE (
		/*
		** Store the current state of applications left, and
		** the current operator, to pop them later.
		*/
		PUSH( applications_remaining, STACK_NEW() );
		PUSH( operator_stack, rator );
		stacked++;
		SET( applications_remaining, 0 );
		goto begin_apply;
	);
	rand = POP( Main_Stack );
	/**/

	/* APPLY */
	switch ( rator->type ) {
	case typeI:
		PUSH( Main_Stack, rand );
		break;
	case typeV:
		PUSH( Main_Stack, V_FUNCTION );
		break;
	case typeDot:
		putchar( rator->data.car );
		PUSH( Main_Stack, rand );
		break;
	case typeK1:	/* First application of K */	
		PUSH( Main_Stack, funktion_new(typeK2,rand,0));
		break;
	case typeK2:	/* The constant function application */
		PUSH( Main_Stack, rator->data.args[0] );
		break;
	case typeS1:	/* First application of S */
		PUSH( Main_Stack, funktion_new(typeS2,rand,0));
		break;
	case typeS2:	/* Second application of S */
		PUSH( Main_Stack,
			funktion_new(typeS3,rator->data.args[0],rand) );
		break;
	case typeS3:	/* Substituted application */
		PUSH( Main_Stack, rand );
		PUSH( Main_Stack, rator->data.args[1] );
		PUSH( Main_Stack, BACKQUOTE );
		PUSH( Main_Stack, rand );
		PUSH( Main_Stack, rator->data.args[0] );
		PUSH( Main_Stack, BACKQUOTE );
		goto begin_apply;
		break;
	case typePromise: {
		/* A promise is expanded into the promised code. */
		Stack *p, *result, *last = STACK_NEW();

		/* Push the already evaluated operand */
		PUSH( Main_Stack, rand );
		
		/* Copy the code to result. */
		result = last;
		for ( p = rator->data.promised_code; FUNVAL(p) != NIL; p = NEXT(p) ) {
			APPEND( last, FUNVAL(p) );
		}
		/* And the main stack after it. */
		FUNVAL(last) = FUNVAL(Main_Stack);
		NEXT(last) = NEXT(Main_Stack);
		Main_Stack = result;
		goto begin_apply;
	}
	case typeC:	/* Call/cc */
		if ( rand == V_FUNCTION )
			PUSH( Main_Stack, V_FUNCTION );
		else {
			/* Create a continuation and apply the operand to it */
			Stack *p, *last;
			Funktion *k;

			NEW(k, Funktion);
			k->type = typeContinuation;
			NEW(k->data.cont, Continuation);
	
			/* Applications remaining are copied because they are
			** actually changed.
			*/
			k->data.cont->applications_remaining = last = STACK_NEW();
			for ( p = applications_remaining;
					FUNVAL(p) != NIL; p = NEXT(p) ) {
				VAL(last) = VAL(p);
				NEXT(last) = STACK_NEW();
				last = NEXT(last);
			}
	
			/* The others shouldn't be changed, thus can be only
			** referenced
			*/
			k->data.cont->main_stack = Main_Stack;
			k->data.cont->operator_stack = operator_stack;
			k->data.cont->stacked = stacked;
			k->data.cont->current_character = current_character;

			PUSH( Main_Stack, k );
			PUSH( Main_Stack, rand );
			goto begin_apply;
		}
		break;
	case typeContinuation: {
		Stack *p, *last;
		
		/* Copy applications remaining */
		applications_remaining = last = STACK_NEW();
		for ( p = rator->data.cont->applications_remaining;
				FUNVAL(p) != NIL; p = NEXT(p) ) {
			VAL(last) = VAL(p);
			NEXT(last) = STACK_NEW();
			last = NEXT(last);
		}

		/* Reference the others */
		Main_Stack = rator->data.cont->main_stack;
		operator_stack = rator->data.cont->operator_stack;
		stacked = rator->data.cont->stacked;
		current_character = rator->data.cont->current_character;
		PUSH( Main_Stack, rand );
		break;
	}
	case typeE:
		/* It returns the number of the operand type
		** (these are the Type enum, above).
		*/
		exit( rand->type );
		break;
	case typeRead:
		if ( ( current_character = getc(stdin) ) != EOF )
			PUSH( Main_Stack, I_FUNCTION );
		else
			PUSH( Main_Stack, V_FUNCTION );
		PUSH( Main_Stack, rand );
		goto begin_apply;
		break;
	case typeCompare:
		if ( rator->data.car == current_character )
			PUSH( Main_Stack, I_FUNCTION );
		else
			PUSH( Main_Stack, V_FUNCTION );
		PUSH( Main_Stack, rand );
		goto begin_apply;
		break;
	case typeReprint:
		if ( current_character != EOF )
			PUSH( Main_Stack, car_funktion_new(typeDot, current_character) );
		else
			PUSH( Main_Stack, V_FUNCTION );
		PUSH( Main_Stack, rand );
		goto begin_apply;
		break;
	default:
		die(errInternal);
	}

end_apply:
	if ( VAL(applications_remaining) == 0 ) {
		/*
		** If there are no applications left;
		*/
		if ( stacked != 1 ) {
			/* either there are operators waiting in the stack */
			POP( applications_remaining );
			PUSH( Main_Stack, POP(operator_stack) );
			stacked--;
			goto begin_apply;
		}
		/* ...or we are done. */		
	} else {
		/* Go for another application */
		INC(applications_remaining, -1);
		goto begin_apply;
	}
}
#undef VAL
#undef SET
#undef INC

void
parse(FILE *f)
{
	unsigned int count = 1;
	Stack *last;
	char c;
	
	last = Main_Stack;
	do {
		c = getc(f);
		count--;
		switch (c) {
		case ' ': case '\t': case '\n':
			count++;
			break;
		case '#':
			while ( (c = getc(f)) != '\n' )
				if ( c == EOF ) die(errEOF);
			count++;
			break;
		case '`': case '\'':
			count += 2;
			APPEND( last, BACKQUOTE );
			break;
		case 's': case 'S':
			APPEND( last, S_FUNCTION );
			break;
		case 'k': case 'K':
			APPEND( last, K_FUNCTION );
			break;		
		case 'i': case 'I':
			APPEND( last, I_FUNCTION );
			break;
		case 'd': case 'D':
			APPEND( last, D_FUNCTION );
			break;
		case 'c': case 'C':
			APPEND( last, C_FUNCTION );
			break;
		case 'v': case 'V':
			APPEND( last, V_FUNCTION );
			break;
		case 'r': case 'R':
			APPEND( last, R_FUNCTION );
			break;
		case 'e': case 'E':
			APPEND( last, E_FUNCTION );
			break;
		case '@':
			APPEND( last, AT_FUNCTION );
			break;
		case '|':
			APPEND( last, PIPE_FUNCTION );
			break;
		case '?':
			if ( ( c = getc(f) ) == EOF ) die(errEOF);
			APPEND( last, car_funktion_new(typeCompare, c) );
			break;
		case '.':
			if ( ( c = getc(f) ) == EOF ) die(errEOF);
			APPEND( last, car_funktion_new(typeDot, c) );
			break;
		case EOF:
			die(errEOF);
			break;
		default:
			die(errChar);
			break;
		}
	} while ( count );
}

void
init(void)
{
	Main_Stack = STACK_NEW();
	R_FUNCTION->data.car = '\n';
}

int
main(int argc, char **argv)
{
	FILE *f;

	if ( argc == 1 )
		f = stdin;
	else if ( argc == 2 ) {
		if ( ! (f = fopen( argv[1], "r")))
			die(errOpen);
	} else
		die(errArgs);
	
	init();
	parse( f );
	if ( fclose(f) )
		die(errClose);

	IF_BACKQUOTE( apply() );
	return 0;
}
