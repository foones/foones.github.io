typedef union {
	Objeto *val;
	unsigned cant; 
	Lista *lista;
	char *cadena;
	Entorno *env;
	char modo;
	Maquina *maq;
} YYSTYPE;
#define	ID	258
#define	LIT	259
#define	ARCHIVO	260
#define	MAQUINA	261
#define	DEF	262
#define	OR	263
#define	FLECHA	264
#define	CONSINFIJO	265
#define	SMILEY	266
#define	YELIMS	267
#define	BACKQUOTE	268
#define	PLEASE	269
#define	CHE	270
#define	COMA	271
#define	NL	272
#define	LPAREN	273
#define	RPAREN	274
#define	LDEFI	275
#define	RDEFI	276
#define	LBRACK	277
#define	RBRACK	278
#define	PUBIC	279
#define	CUBIC	280
#define	RUBIK	281
#define	HLADIK	282
#define	MAGIC	283
#define	PLASTIC	284
#define	VOID	285
#define	LIZARD	286
#define	ESTAFRIO	287
#define	WARP	288
#define	BGEN	289
#define	EGEN	290
#define	BDONDE	291
#define	EDONDE	292
#define	BCAPSULA	293
#define	ECAPSULA	294
#define	BUNL	295
#define	EUNL	296
#define	BMAQ	297
#define	EMAQ	298
#define	BCHARLATAN	299
#define	ECHARLATAN	300
#define	BKOAN	301
#define	EKOAN	302
#define	TEOF	303
#define	GUARDA	304
#define	SINO	305
#define	BCHONGOL	306
#define	ECHONGOL	307
#define	SEMICOLON	308
#define	TIF	309
#define	TENDIF	310


extern YYSTYPE yylval;
