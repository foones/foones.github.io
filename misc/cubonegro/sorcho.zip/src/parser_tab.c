
/*  A Bison parser, made from parser.y
 by  GNU Bison version 1.25
  */

#define YYBISON 1  /* Identify Bison output.  */

#define	ID	258
#define	LIT	259
#define	ARCHIVO	260
#define	MAQUINA	261
#define	DEF	262
#define	OR	263
#define	FLECHA	264
#define	CONSINFIJO	265
#define	SMILEY	266
#define	YELIMS	267
#define	BACKQUOTE	268
#define	PLEASE	269
#define	CHE	270
#define	COMA	271
#define	NL	272
#define	LPAREN	273
#define	RPAREN	274
#define	LDEFI	275
#define	RDEFI	276
#define	LBRACK	277
#define	RBRACK	278
#define	PUBIC	279
#define	CUBIC	280
#define	RUBIK	281
#define	HLADIK	282
#define	MAGIC	283
#define	PLASTIC	284
#define	VOID	285
#define	LIZARD	286
#define	ESTAFRIO	287
#define	WARP	288
#define	BGEN	289
#define	EGEN	290
#define	BDONDE	291
#define	EDONDE	292
#define	BCAPSULA	293
#define	ECAPSULA	294
#define	BUNL	295
#define	EUNL	296
#define	BMAQ	297
#define	EMAQ	298
#define	BCHARLATAN	299
#define	ECHARLATAN	300
#define	BKOAN	301
#define	EKOAN	302
#define	TEOF	303
#define	GUARDA	304
#define	SINO	305
#define	BCHONGOL	306
#define	ECHONGOL	307
#define	SEMICOLON	308
#define	TIF	309
#define	TENDIF	310

#line 1 "parser.y"

#include <stdlib.h>
#include "Sor.h"

#line 5 "parser.y"
typedef union {
	Objeto *val;
	unsigned cant; 
	Lista *lista;
	char *cadena;
	Entorno *env;
	char modo;
	Maquina *maq;
} YYSTYPE;
#include <stdio.h>

#ifndef __cplusplus
#ifndef __STDC__
#define const
#endif
#endif



#define	YYFINAL		133
#define	YYFLAG		-32768
#define	YYNTBASE	56

#define YYTRANSLATE(x) ((unsigned)(x) <= 310 ? yytranslate[x] : 85)

static const char yytranslate[] = {     0,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     1,     2,     3,     4,     5,
     6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
    16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
    26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
    36,    37,    38,    39,    40,    41,    42,    43,    44,    45,
    46,    47,    48,    49,    50,    51,    52,    53,    54,    55
};

#if YYDEBUG != 0
static const short yyprhs[] = {     0,
     0,     3,     7,    13,    15,    19,    21,    22,    26,    30,
    35,    39,    44,    49,    51,    52,    58,    60,    64,    70,
    72,    75,    77,    79,    83,    87,    91,    95,    97,    99,
   103,   107,   111,   113,   117,   118,   123,   124,   127,   131,
   133,   137,   139,   141,   145,   146,   149,   153,   156,   160,
   161,   164,   166,   168,   170,   172,   174,   176,   178,   180,
   182,   184,   186,   188,   190,   192,   194,   195,   199,   201,
   203,   208,   210
};

static const short yyrhs[] = {    63,
    17,     0,    20,    57,    21,     0,    77,    78,    79,     3,
     6,     0,    80,     0,    51,    81,    52,     0,    48,     0,
     0,    58,    17,    57,     0,    15,    16,    59,     0,    14,
     3,     7,    75,     0,    14,     7,    75,     0,     3,    68,
     7,    60,     0,     3,    68,     7,    60,     0,    62,     0,
     0,    62,    36,    61,    57,    37,     0,    63,     0,    50,
     7,    63,     0,    49,    63,     7,    63,    62,     0,    64,
     0,    63,    64,     0,    71,     0,    72,     0,    18,    63,
    19,     0,    18,    69,    19,     0,    34,    70,    35,     0,
    40,    65,    41,     0,    74,     0,    66,     0,    64,    11,
     3,     0,     3,    12,    64,     0,    42,     6,    43,     0,
    64,     0,    13,    64,    64,     0,     0,    38,    67,    57,
    39,     0,     0,    63,    68,     0,    63,     9,    63,     0,
    63,     0,    63,     8,    70,     0,     3,     0,     4,     0,
    22,    73,    23,     0,     0,    63,    73,     0,    64,    10,
    64,     0,     3,    76,     0,    75,     8,    75,     0,     0,
    76,     3,     0,    26,     0,    24,     0,    25,     0,    27,
     0,    28,     0,    29,     0,    30,     0,    31,     0,    32,
     0,    33,     0,    44,     0,    45,     0,     5,     0,    46,
     0,    47,     0,     0,    82,    53,    81,     0,    83,     0,
    71,     0,    83,    18,    84,    19,     0,    83,     0,    83,
    16,    84,     0
};

#endif

#if YYDEBUG != 0
static const short yyrline[] = { 0,
    48,    52,    57,    65,    69,    74,    79,    81,    84,    86,
    87,    88,   104,   112,   114,   121,   129,   131,   132,   140,
   142,   155,   157,   158,   159,   161,   163,   165,   166,   167,
   184,   201,   209,   211,   217,   224,   232,   234,   237,   243,
   245,   248,   258,   261,   265,   277,   291,   306,   312,   315,
   317,   320,   321,   322,   325,   326,   327,   330,   331,   332,
   333,   336,   338,   339,   340,   344,   347,   349,   352,   356,
   358,   370,   373
};
#endif


#if YYDEBUG != 0 || defined (YYERROR_VERBOSE)

static const char * const yytname[] = {   "$","error","$undefined.","ID","LIT",
"ARCHIVO","MAQUINA","DEF","OR","FLECHA","CONSINFIJO","SMILEY","YELIMS","BACKQUOTE",
"PLEASE","CHE","COMA","NL","LPAREN","RPAREN","LDEFI","RDEFI","LBRACK","RBRACK",
"PUBIC","CUBIC","RUBIK","HLADIK","MAGIC","PLASTIC","VOID","LIZARD","ESTAFRIO",
"WARP","BGEN","EGEN","BDONDE","EDONDE","BCAPSULA","ECAPSULA","BUNL","EUNL","BMAQ",
"EMAQ","BCHARLATAN","ECHARLATAN","BKOAN","EKOAN","TEOF","GUARDA","SINO","BCHONGOL",
"ECHONGOL","SEMICOLON","TIF","TENDIF","sexpr","definiciones","definicion","definicion_simple",
"expr_donde","@1","guardas","expr","expr_baja","unlambdosa","capsula","@2","argumentos",
"lambda_expr","lista_generica","atom","listas","lista_de_conses","cons_infijo",
"decltipo","lista_tipos","wrap_mode","eval_mode","otro_mode","opcion","chongol_programa",
"chongol_stmt","chongol_expresion","chongol_parametros", NULL
};
#endif

static const short yyr1[] = {     0,
    56,    56,    56,    56,    56,    56,    57,    57,    58,    58,
    58,    58,    59,    60,    61,    60,    62,    62,    62,    63,
    63,    64,    64,    64,    64,    64,    64,    64,    64,    64,
    64,    64,    65,    65,    67,    66,    68,    68,    69,    70,
    70,    71,    71,    72,    73,    73,    74,    75,    75,    76,
    76,    77,    77,    77,    78,    78,    78,    79,    79,    79,
    79,    80,    80,    80,    80,    80,    81,    81,    82,    83,
    83,    84,    84
};

static const short yyr2[] = {     0,
     2,     3,     5,     1,     3,     1,     0,     3,     3,     4,
     3,     4,     4,     1,     0,     5,     1,     3,     5,     1,
     2,     1,     1,     3,     3,     3,     3,     1,     1,     3,
     3,     3,     1,     3,     0,     4,     0,     2,     3,     1,
     3,     1,     1,     3,     0,     2,     3,     2,     3,     0,
     2,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     0,     3,     1,     1,
     4,     1,     3
};

static const short yydefact[] = {     0,
    42,    43,    64,     0,     7,    45,    53,    54,    52,     0,
    35,     0,     0,    62,    63,    65,    66,     6,    67,     0,
    20,    29,    22,    23,    28,     0,     4,     0,     0,     0,
    37,     0,     0,     0,     0,    45,     0,    40,     0,     7,
     0,    33,     0,     0,    42,    70,     0,     0,    69,     1,
    21,     0,     0,    55,    56,    57,     0,    31,     0,    24,
    25,    37,     0,     0,     0,     0,     2,     7,    20,    46,
    44,     0,    26,     0,     0,    27,    32,     5,    67,     0,
    47,    30,    58,    59,    60,    61,     0,    39,    38,     0,
     0,    50,    11,    37,     9,     8,    41,    36,    34,    68,
    72,     0,     0,     0,     0,    12,    14,    17,    10,    48,
     0,     0,     0,    71,     3,     0,     0,    15,    51,    49,
     0,    73,     0,    18,     7,    13,     0,     0,    19,    16,
     0,     0,     0
};

static const short yydefgoto[] = {   131,
    34,    35,    95,   106,   125,   107,    62,    21,    43,    22,
    40,    63,    30,    39,    23,    24,    37,    25,    93,   110,
    26,    57,    87,    27,    47,    48,    49,   102
};

static const short yypact[] = {   104,
    12,-32768,-32768,   204,    20,   204,-32768,-32768,-32768,   204,
-32768,    53,    26,-32768,-32768,-32768,-32768,-32768,    36,    97,
    50,-32768,-32768,-32768,-32768,    -8,-32768,   204,   150,    24,
   204,     8,    39,    31,    41,   204,    42,   178,    34,    20,
   204,    50,    29,    30,-32768,-32768,    22,    23,    60,-32768,
    50,   204,    76,-32768,-32768,-32768,    17,-32768,   204,-32768,
-32768,   204,    73,    74,    79,    80,-32768,    20,    18,-32768,
-32768,   204,-32768,    45,   153,-32768,-32768,-32768,    36,    36,
    50,-32768,-32768,-32768,-32768,-32768,    82,   204,-32768,     4,
    79,-32768,    78,   204,-32768,-32768,-32768,-32768,    50,-32768,
    -2,    70,    86,   204,    87,-32768,    62,   204,    78,    96,
    79,    95,    36,-32768,-32768,   195,   204,-32768,-32768,-32768,
     4,-32768,   204,   204,    20,-32768,     4,    66,-32768,-32768,
   106,   110,-32768
};

static const short yypgoto[] = {-32768,
   -37,-32768,-32768,   -10,-32768,   -15,     0,   -11,-32768,-32768,
-32768,   -57,-32768,    46,   -17,-32768,    84,-32768,   -78,-32768,
-32768,-32768,-32768,-32768,    54,-32768,   -68,    19
};


#define	YYLAST		246


static const short yytable[] = {    20,
    42,    46,    74,    29,    89,    36,     1,     2,    51,    38,
    64,   101,   109,   113,    65,    80,    58,    51,    54,    55,
    56,     4,    31,    28,    69,     6,    51,    52,    53,    75,
    96,    44,   120,    32,    33,    36,   112,    10,    45,     2,
    81,    11,    61,    12,   101,    13,    83,    84,    85,    86,
    69,    67,   104,   105,    66,     1,     2,    68,    88,    52,
    53,    46,    46,    99,    71,    41,   -21,   -21,    73,    76,
     4,    38,    77,    78,     6,    79,    51,    80,    82,    90,
    91,    92,    94,    98,   103,   111,    10,   128,   114,   108,
    11,   115,    12,   117,    13,    46,    51,   118,   119,     1,
     2,   121,   130,   116,    51,   132,     1,     2,     3,   133,
   126,   129,    51,    50,     4,    69,   124,    97,     6,    70,
   108,     4,   127,     5,     0,     6,   108,     7,     8,     9,
    10,   122,   100,     0,    11,     0,    12,    10,    13,     0,
     0,    11,     0,    12,     0,    13,     0,    14,    15,    16,
    17,    18,     1,     2,    19,     1,     2,     0,    59,     0,
     0,     0,    52,    53,     0,     0,     0,     4,    60,     0,
     4,     6,     0,     0,     6,     0,     0,     0,     0,     0,
     1,     2,     0,    10,     0,    72,    10,    11,     0,    12,
    11,    13,    12,     0,    13,     4,     0,     1,     2,     6,
     0,   123,     0,     0,     0,     0,     1,     2,     0,     0,
     0,    10,     4,     0,     0,    11,     6,    12,     0,    13,
     0,     4,     0,     0,     0,     6,     0,     0,    10,     0,
     0,     0,    11,     0,    12,     0,    13,    10,     0,     0,
     0,    11,     0,    12,     0,    13
};

static const short yycheck[] = {     0,
    12,    19,    40,     4,    62,     6,     3,     4,    20,    10,
     3,    80,    91,    16,     7,    18,    28,    29,    27,    28,
    29,    18,     3,    12,    36,    22,    38,    10,    11,    41,
    68,     6,   111,    14,    15,    36,    94,    34,     3,     4,
    52,    38,    19,    40,   113,    42,    30,    31,    32,    33,
    62,    21,    49,    50,    16,     3,     4,    17,    59,    10,
    11,    79,    80,    75,    23,    13,    49,    50,    35,    41,
    18,    72,    43,    52,    22,    53,    88,    18,     3,     7,
     7,     3,     3,    39,     3,     8,    34,   125,    19,    90,
    38,     6,    40,     7,    42,   113,   108,    36,     3,     3,
     4,     7,    37,   104,   116,     0,     3,     4,     5,     0,
   121,   127,   124,    17,    18,   127,   117,    72,    22,    36,
   121,    18,   123,    20,    -1,    22,   127,    24,    25,    26,
    34,   113,    79,    -1,    38,    -1,    40,    34,    42,    -1,
    -1,    38,    -1,    40,    -1,    42,    -1,    44,    45,    46,
    47,    48,     3,     4,    51,     3,     4,    -1,     9,    -1,
    -1,    -1,    10,    11,    -1,    -1,    -1,    18,    19,    -1,
    18,    22,    -1,    -1,    22,    -1,    -1,    -1,    -1,    -1,
     3,     4,    -1,    34,    -1,     8,    34,    38,    -1,    40,
    38,    42,    40,    -1,    42,    18,    -1,     3,     4,    22,
    -1,     7,    -1,    -1,    -1,    -1,     3,     4,    -1,    -1,
    -1,    34,    18,    -1,    -1,    38,    22,    40,    -1,    42,
    -1,    18,    -1,    -1,    -1,    22,    -1,    -1,    34,    -1,
    -1,    -1,    38,    -1,    40,    -1,    42,    34,    -1,    -1,
    -1,    38,    -1,    40,    -1,    42
};
/* -*-C-*-  Note some compilers choke on comments on `#line' lines.  */
#line 3 "bison.simple"

/* Skeleton output parser for bison,
   Copyright (C) 1984, 1989, 1990 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

#ifndef alloca
#ifdef __GNUC__
#define alloca __builtin_alloca
#else /* not GNU C.  */
#if (!defined (__STDC__) && defined (sparc)) || defined (__sparc__) || defined (__sparc) || defined (__sgi)
#include <alloca.h>
#else /* not sparc */
#if defined (MSDOS) && !defined (__TURBOC__)
#include <malloc.h>
#else /* not MSDOS, or __TURBOC__ */
#if defined(_AIX)
#include <malloc.h>
 #pragma alloca
#else /* not MSDOS, __TURBOC__, or _AIX */
#ifdef __hpux
#ifdef __cplusplus
extern "C" {
void *alloca (unsigned int);
};
#else /* not __cplusplus */
void *alloca ();
#endif /* not __cplusplus */
#endif /* __hpux */
#endif /* not _AIX */
#endif /* not MSDOS, or __TURBOC__ */
#endif /* not sparc.  */
#endif /* not GNU C.  */
#endif /* alloca not defined.  */

/* This is the parser code that is written into each bison parser
  when the %semantic_parser declaration is not specified in the grammar.
  It was written by Richard Stallman by simplifying the hairy parser
  used when %semantic_parser is specified.  */

/* Note: there must be only one dollar sign in this file.
   It is replaced by the list of actions, each action
   as one case of the switch.  */

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		-2
#define YYEOF		0
#define YYACCEPT	return(0)
#define YYABORT 	return(1)
#define YYERROR		goto yyerrlab1
/* Like YYERROR except do call yyerror.
   This remains here temporarily to ease the
   transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */
#define YYFAIL		goto yyerrlab
#define YYRECOVERING()  (!!yyerrstatus)
#define YYBACKUP(token, value) \
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    { yychar = (token), yylval = (value);			\
      yychar1 = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { yyerror ("syntax error: cannot back up"); YYERROR; }	\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

#ifndef YYPURE
#define YYLEX		yylex()
#endif

#ifdef YYPURE
#ifdef YYLSP_NEEDED
#ifdef YYLEX_PARAM
#define YYLEX		yylex(&yylval, &yylloc, YYLEX_PARAM)
#else
#define YYLEX		yylex(&yylval, &yylloc)
#endif
#else /* not YYLSP_NEEDED */
#ifdef YYLEX_PARAM
#define YYLEX		yylex(&yylval, YYLEX_PARAM)
#else
#define YYLEX		yylex(&yylval)
#endif
#endif /* not YYLSP_NEEDED */
#endif

/* If nonreentrant, generate the variables here */

#ifndef YYPURE

int	yychar;			/*  the lookahead symbol		*/
YYSTYPE	yylval;			/*  the semantic value of the		*/
				/*  lookahead symbol			*/

#ifdef YYLSP_NEEDED
YYLTYPE yylloc;			/*  location data for the lookahead	*/
				/*  symbol				*/
#endif

int yynerrs;			/*  number of parse errors so far       */
#endif  /* not YYPURE */

#if YYDEBUG != 0
int yydebug;			/*  nonzero means print parse trace	*/
/* Since this is uninitialized, it does not stop multiple parsers
   from coexisting.  */
#endif

/*  YYINITDEPTH indicates the initial size of the parser's stacks	*/

#ifndef	YYINITDEPTH
#define YYINITDEPTH 200
#endif

/*  YYMAXDEPTH is the maximum size the stacks can grow to
    (effective only if the built-in stack extension method is used).  */

#if YYMAXDEPTH == 0
#undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
#define YYMAXDEPTH 10000
#endif

/* Prevent warning if -Wstrict-prototypes.  */
#ifdef __GNUC__
int yyparse (void);
#endif

#if __GNUC__ > 1		/* GNU C and GNU C++ define this.  */
#define __yy_memcpy(TO,FROM,COUNT)	__builtin_memcpy(TO,FROM,COUNT)
#else				/* not GNU C or C++ */
#ifndef __cplusplus

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_memcpy (to, from, count)
     char *to;
     char *from;
     int count;
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#else /* __cplusplus */

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_memcpy (char *to, char *from, int count)
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#endif
#endif

#line 196 "bison.simple"

/* The user can define YYPARSE_PARAM as the name of an argument to be passed
   into yyparse.  The argument should have type void *.
   It should actually point to an object.
   Grammar actions can access the variable by casting it
   to the proper pointer type.  */

#ifdef YYPARSE_PARAM
#ifdef __cplusplus
#define YYPARSE_PARAM_ARG void *YYPARSE_PARAM
#define YYPARSE_PARAM_DECL
#else /* not __cplusplus */
#define YYPARSE_PARAM_ARG YYPARSE_PARAM
#define YYPARSE_PARAM_DECL void *YYPARSE_PARAM;
#endif /* not __cplusplus */
#else /* not YYPARSE_PARAM */
#define YYPARSE_PARAM_ARG
#define YYPARSE_PARAM_DECL
#endif /* not YYPARSE_PARAM */

int
yyparse(YYPARSE_PARAM_ARG)
     YYPARSE_PARAM_DECL
{
  register int yystate;
  register int yyn;
  register short *yyssp;
  register YYSTYPE *yyvsp;
  int yyerrstatus;	/*  number of tokens to shift before error messages enabled */
  int yychar1 = 0;		/*  lookahead token as an internal (translated) token number */

  short	yyssa[YYINITDEPTH];	/*  the state stack			*/
  YYSTYPE yyvsa[YYINITDEPTH];	/*  the semantic value stack		*/

  short *yyss = yyssa;		/*  refer to the stacks thru separate pointers */
  YYSTYPE *yyvs = yyvsa;	/*  to allow yyoverflow to reallocate them elsewhere */

#ifdef YYLSP_NEEDED
  YYLTYPE yylsa[YYINITDEPTH];	/*  the location stack			*/
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;

#define YYPOPSTACK   (yyvsp--, yyssp--, yylsp--)
#else
#define YYPOPSTACK   (yyvsp--, yyssp--)
#endif

  int yystacksize = YYINITDEPTH;

#ifdef YYPURE
  int yychar;
  YYSTYPE yylval;
  int yynerrs;
#ifdef YYLSP_NEEDED
  YYLTYPE yylloc;
#endif
#endif

  YYSTYPE yyval;		/*  the variable used to return		*/
				/*  semantic values from the action	*/
				/*  routines				*/

  int yylen;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Starting parse\n");
#endif

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss - 1;
  yyvsp = yyvs;
#ifdef YYLSP_NEEDED
  yylsp = yyls;
#endif

/* Push a new state, which is found in  yystate  .  */
/* In all cases, when you get here, the value and location stacks
   have just been pushed. so pushing a state here evens the stacks.  */
yynewstate:

  *++yyssp = yystate;

  if (yyssp >= yyss + yystacksize - 1)
    {
      /* Give user a chance to reallocate the stack */
      /* Use copies of these so that the &'s don't force the real ones into memory. */
      YYSTYPE *yyvs1 = yyvs;
      short *yyss1 = yyss;
#ifdef YYLSP_NEEDED
      YYLTYPE *yyls1 = yyls;
#endif

      /* Get the current used size of the three stacks, in elements.  */
      int size = yyssp - yyss + 1;

#ifdef yyoverflow
      /* Each stack pointer address is followed by the size of
	 the data in use in that stack, in bytes.  */
#ifdef YYLSP_NEEDED
      /* This used to be a conditional around just the two extra args,
	 but that might be undefined if yyoverflow is a macro.  */
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
		 &yyls1, size * sizeof (*yylsp),
		 &yystacksize);
#else
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
		 &yystacksize);
#endif

      yyss = yyss1; yyvs = yyvs1;
#ifdef YYLSP_NEEDED
      yyls = yyls1;
#endif
#else /* no yyoverflow */
      /* Extend the stack our own way.  */
      if (yystacksize >= YYMAXDEPTH)
	{
	  yyerror("parser stack overflow");
	  return 2;
	}
      yystacksize *= 2;
      if (yystacksize > YYMAXDEPTH)
	yystacksize = YYMAXDEPTH;
      yyss = (short *) alloca (yystacksize * sizeof (*yyssp));
      __yy_memcpy ((char *)yyss, (char *)yyss1, size * sizeof (*yyssp));
      yyvs = (YYSTYPE *) alloca (yystacksize * sizeof (*yyvsp));
      __yy_memcpy ((char *)yyvs, (char *)yyvs1, size * sizeof (*yyvsp));
#ifdef YYLSP_NEEDED
      yyls = (YYLTYPE *) alloca (yystacksize * sizeof (*yylsp));
      __yy_memcpy ((char *)yyls, (char *)yyls1, size * sizeof (*yylsp));
#endif
#endif /* no yyoverflow */

      yyssp = yyss + size - 1;
      yyvsp = yyvs + size - 1;
#ifdef YYLSP_NEEDED
      yylsp = yyls + size - 1;
#endif

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Stack size increased to %d\n", yystacksize);
#endif

      if (yyssp >= yyss + yystacksize - 1)
	YYABORT;
    }

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Entering state %d\n", yystate);
#endif

  goto yybackup;
 yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* yychar is either YYEMPTY or YYEOF
     or a valid token in external form.  */

  if (yychar == YYEMPTY)
    {
#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Reading a token: ");
#endif
      yychar = YYLEX;
    }

  /* Convert token to internal form (in yychar1) for indexing tables with */

  if (yychar <= 0)		/* This means end of input. */
    {
      yychar1 = 0;
      yychar = YYEOF;		/* Don't call YYLEX any more */

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Now at end of input.\n");
#endif
    }
  else
    {
      yychar1 = YYTRANSLATE(yychar);

#if YYDEBUG != 0
      if (yydebug)
	{
	  fprintf (stderr, "Next token is %d (%s", yychar, yytname[yychar1]);
	  /* Give the individual parser a way to print the precise meaning
	     of a token, for further debugging info.  */
#ifdef YYPRINT
	  YYPRINT (stderr, yychar, yylval);
#endif
	  fprintf (stderr, ")\n");
	}
#endif
    }

  yyn += yychar1;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != yychar1)
    goto yydefault;

  yyn = yytable[yyn];

  /* yyn is what to do for this token type in this state.
     Negative => reduce, -yyn is rule number.
     Positive => shift, yyn is new state.
       New state is final state => don't bother to shift,
       just return success.
     0, or most negative number => error.  */

  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrlab;

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting token %d (%s), ", yychar, yytname[yychar1]);
#endif

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  /* count tokens shifted since error; after three, turn off error status.  */
  if (yyerrstatus) yyerrstatus--;

  yystate = yyn;
  goto yynewstate;

/* Do the default action for the current state.  */
yydefault:

  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;

/* Do a reduction.  yyn is the number of a rule to reduce with.  */
yyreduce:
  yylen = yyr2[yyn];
  if (yylen > 0)
    yyval = yyvsp[1-yylen]; /* implement default value of the action */

#if YYDEBUG != 0
  if (yydebug)
    {
      int i;

      fprintf (stderr, "Reducing via rule %d (line %d), ",
	       yyn, yyrline[yyn]);

      /* Print the symbols being reduced, and their result.  */
      for (i = yyprhs[yyn]; yyrhs[i] > 0; i++)
	fprintf (stderr, "%s ", yytname[yyrhs[i]]);
      fprintf (stderr, " -> %s\n", yytname[yyr1[yyn]]);
    }
#endif


  switch (yyn) {

case 1:
#line 48 "parser.y"
{
			Read_Sexpr = yyvsp[-1].val;
			return 1;
			;
    break;}
case 2:
#line 53 "parser.y"
{
			Read_Sexpr = mk_nada();
			return 1;
			;
    break;}
case 3:
#line 57 "parser.y"
{
			yyvsp[0].maq->wrap_mode = yyvsp[-4].modo;
			yyvsp[0].maq->eval_mode = yyvsp[-3].modo;
			yyvsp[0].maq->otro_mode = yyvsp[-2].modo;
			hash_set(Actual, VAL_NOMBRE(yyvsp[-1].val), mk_maquina(yyvsp[0].maq));
			Read_Sexpr = mk_nada();
			return 1;
			;
    break;}
case 4:
#line 65 "parser.y"
{
			Read_Sexpr = mk_nada();
			return 1;
			;
    break;}
case 5:
#line 70 "parser.y"
{
			Read_Sexpr = mk_nada();
			return 1;
			;
    break;}
case 6:
#line 74 "parser.y"
{
			return 0;
			;
    break;}
case 12:
#line 89 "parser.y"
{
	Objeto *ant;
	Lista *l;

	ant = hash_get(Actual, VAL_NOMBRE(yyvsp[-3].val));
	if (ant && (ant->tipo == tipo_generica))
		l = VAL_GENERICA(ant);
	else
		l = 0;
	hash_set(Actual, VAL_NOMBRE(yyvsp[-3].val),
		mk_generica(mk_par(
			mk_curry(Pila_Actuales, yyvsp[-2].lista, yyvsp[0].val), l)));
	;
    break;}
case 13:
#line 106 "parser.y"
{
	hash_set(Actual, VAL_NOMBRE(yyvsp[-3].val),
		mk_curry(Pila_Actuales, yyvsp[-2].lista, yyvsp[0].val));
	;
    break;}
case 15:
#line 116 "parser.y"
{
	Actual = mk_hash(HASH_PRIMO);
	Pila_Actuales = mk_entorno(Actual, Pila_Actuales);
	;
    break;}
case 16:
#line 122 "parser.y"
{
	yyval.val = mk_dondura(Actual, yyvsp[-4].val);
	Pila_Actuales = Pila_Actuales->padre;
	Actual = Pila_Actuales->hash;
	;
    break;}
case 18:
#line 131 "parser.y"
{ yyval.val = yyvsp[0].val; ;
    break;}
case 19:
#line 133 "parser.y"
{
	yyval.val = mk_aplicacion(
	mk_aplicacion(mk_aplicacion(mk_simbolo("si"), yyvsp[-3].val), yyvsp[-1].val),
	yyvsp[0].val);
	;
    break;}
case 21:
#line 143 "parser.y"
{
		if (yyvsp[-1].val->tipo == tipo_constructor) {
			yyval.val = mk_construccion(yyvsp[-1].val, yyvsp[0].val);
		} else if ( yyvsp[-1].val->tipo == tipo_construccion ) {
			construccion_push(yyvsp[-1].val, yyvsp[0].val);
			yyval.val = yyvsp[-1].val;
		} else {
			yyval.val = mk_aplicacion(yyvsp[-1].val, yyvsp[0].val);
		}
		;
    break;}
case 24:
#line 158 "parser.y"
{ yyval.val = yyvsp[-1].val; ;
    break;}
case 25:
#line 160 "parser.y"
{ yyval.val = yyvsp[-1].val; ;
    break;}
case 26:
#line 162 "parser.y"
{ yyval.val = mk_generica(yyvsp[-1].lista); ;
    break;}
case 27:
#line 164 "parser.y"
{ yyval.val = yyvsp[-1].val; ;
    break;}
case 30:
#line 168 "parser.y"
{
		Objeto *f;
		Objeto *o;

		f = reducir(Pila_Actuales, yyvsp[-2].val);
		if (f->tipo != tipo_entorno ||
		!(o = binding(VAL_ENTORNO(f), VAL_NOMBRE(yyvsp[0].val)))) {
			fail("El obrero fue aplastado por las vigas", yyvsp[-2].val);
		}

		if (o->tipo == tipo_constructor) {
			yyval.val = o;
		} else {
			yyval.val = mk_cerradura(VAL_ENTORNO(f), o);
		}
	;
    break;}
case 31:
#line 185 "parser.y"
{
		Objeto *f;
		Objeto *o;

		f = reducir(Pila_Actuales, yyvsp[0].val);
		if (f->tipo != tipo_entorno ||
		!(o = binding(VAL_ENTORNO(f), VAL_NOMBRE(yyvsp[-2].val)))) {
			fail("The worker has been smashed", yyvsp[0].val);
		}

		if (o->tipo == tipo_constructor) {
			yyval.val = o;
		} else {
			yyval.val = mk_cerradura(VAL_ENTORNO(f), o);
		}
	;
    break;}
case 32:
#line 201 "parser.y"
{
			yyvsp[-1].maq->wrap_mode = WRAP_TOROIDE;
			yyvsp[-1].maq->eval_mode = EVAL_STRICT;
			yyvsp[-1].maq->otro_mode = OTRO_CERO;
			yyval.val = mk_maquina(yyvsp[-1].maq);
			;
    break;}
case 34:
#line 212 "parser.y"
{
		yyval.val = mk_aplicacion(yyvsp[-1].val, yyvsp[0].val);
	;
    break;}
case 35:
#line 219 "parser.y"
{
	Actual = mk_hash(HASH_PRIMO);
	Pila_Actuales = mk_entorno(Actual, Pila_Actuales);
	;
    break;}
case 36:
#line 225 "parser.y"
{
	yyval.val = mk_objeto_entorno(Pila_Actuales);
	Pila_Actuales = Pila_Actuales->padre;
	Actual = Pila_Actuales->hash;
	;
    break;}
case 37:
#line 233 "parser.y"
{ yyval.lista = 0; ;
    break;}
case 38:
#line 234 "parser.y"
{ yyval.lista = mk_par(yyvsp[-1].val, yyvsp[0].lista); ;
    break;}
case 39:
#line 239 "parser.y"
{ yyval.val = mk_cerradura(Pila_Actuales,
			mk_funcion(Pila_Actuales, yyvsp[-2].val, yyvsp[0].val)); ;
    break;}
case 40:
#line 244 "parser.y"
{ yyval.lista = mk_par(yyvsp[0].val, 0); ;
    break;}
case 41:
#line 245 "parser.y"
{ yyval.lista = mk_par(yyvsp[-2].val, yyvsp[0].lista); ;
    break;}
case 42:
#line 248 "parser.y"
{
		Objeto *r;

		r = binding(Pila_Actuales, VAL_NOMBRE(yyvsp[0].val));
		if (r && (r->tipo == tipo_constructor)) {
			yyval.val = r;
		} else {
			yyval.val = yyvsp[0].val;
		}
		;
    break;}
case 44:
#line 262 "parser.y"
{ yyval.val = yyvsp[-1].val; ;
    break;}
case 45:
#line 266 "parser.y"
{
	
			Objeto *r;

			r = binding(Pila_Actuales, "Nil");
			if (r && (r->tipo == tipo_constructor)) {
				yyval.val = r;
			} else {
				yyval.val = mk_simbolo("Nil");
			}
			;
    break;}
case 46:
#line 278 "parser.y"
{
			Objeto *l = binding(Pila_Actuales, "Cons");

			if (!l) {
				fail("Bebe las gotas de rocio al amanecer.",
					mk_simbolo("Raindrop Prelude, Chopin"));
			}

			yyval.val = mk_construccion(l, yyvsp[-1].val);
			construccion_push(yyval.val, yyvsp[0].val);
			;
    break;}
case 47:
#line 293 "parser.y"
{
			Objeto *l = binding(Pila_Actuales, "Cons");

			if (!l) {
				fail("Tenes los cordones desatados.",
					mk_simbolo("Raindrop Prelude, Chopin"));
			}

			yyval.val = mk_construccion(l, yyvsp[-2].val);
			construccion_push(yyval.val, yyvsp[0].val);
			;
    break;}
case 48:
#line 308 "parser.y"
{
		hash_set(Actual, VAL_NOMBRE(yyvsp[-1].val),
			mk_constructor(VAL_NOMBRE(yyvsp[-1].val), yyvsp[0].cant));
		;
    break;}
case 50:
#line 316 "parser.y"
{ yyval.cant = 0; ;
    break;}
case 51:
#line 317 "parser.y"
{ yyval.cant = yyvsp[-1].cant + 1; ;
    break;}
case 52:
#line 320 "parser.y"
{ yyval.modo = WRAP_TOROIDE; ;
    break;}
case 53:
#line 321 "parser.y"
{ yyval.modo = WRAP_REFLEJAR; ;
    break;}
case 54:
#line 322 "parser.y"
{ yyval.modo = WRAP_DOBLAR; ;
    break;}
case 55:
#line 325 "parser.y"
{ yyval.modo = EVAL_STRICT; ;
    break;}
case 56:
#line 326 "parser.y"
{ yyval.modo = EVAL_LAZY; ;
    break;}
case 57:
#line 327 "parser.y"
{ yyval.modo = EVAL_STRICT; ;
    break;}
case 58:
#line 330 "parser.y"
{ yyval.modo = 0; ;
    break;}
case 59:
#line 331 "parser.y"
{ yyval.modo = 1; ;
    break;}
case 60:
#line 332 "parser.y"
{ yyval.modo = 0; ;
    break;}
case 61:
#line 333 "parser.y"
{ yyval.modo = 1; ;
    break;}
case 62:
#line 337 "parser.y"
{ Charlatan = 1; ;
    break;}
case 63:
#line 338 "parser.y"
{ Charlatan = 0; ;
    break;}
case 64:
#line 339 "parser.y"
{ cargar_archivo(yyvsp[0].cadena, 0); ;
    break;}
case 65:
#line 340 "parser.y"
{
			Koan = 1;
			srandom((unsigned int) Read_Sexpr);
			;
    break;}
case 66:
#line 344 "parser.y"
{ Koan = 0; ;
    break;}
case 69:
#line 353 "parser.y"
{;
    break;}
case 71:
#line 359 "parser.y"
{
	Objeto *f = yyvsp[-3].val;
	Lista *l;

	for (l = yyvsp[-1].lista; l; l = l->siguiente) {
		f = mk_aplicacion(f, l->elemento);
	}
	yyval.val = f;
	;
    break;}
case 72:
#line 372 "parser.y"
{ yyval.lista = mk_par(yyvsp[0].val, 0); ;
    break;}
case 73:
#line 374 "parser.y"
{ yyval.lista = mk_par(yyvsp[-2].val, yyvsp[0].lista); ;
    break;}
}
   /* the action file gets copied in in place of this dollarsign */
#line 498 "bison.simple"

  yyvsp -= yylen;
  yyssp -= yylen;
#ifdef YYLSP_NEEDED
  yylsp -= yylen;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

  *++yyvsp = yyval;

#ifdef YYLSP_NEEDED
  yylsp++;
  if (yylen == 0)
    {
      yylsp->first_line = yylloc.first_line;
      yylsp->first_column = yylloc.first_column;
      yylsp->last_line = (yylsp-1)->last_line;
      yylsp->last_column = (yylsp-1)->last_column;
      yylsp->text = 0;
    }
  else
    {
      yylsp->last_line = (yylsp+yylen-1)->last_line;
      yylsp->last_column = (yylsp+yylen-1)->last_column;
    }
#endif

  /* Now "shift" the result of the reduction.
     Determine what state that goes to,
     based on the state we popped back to
     and the rule number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTBASE] + *yyssp;
  if (yystate >= 0 && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTBASE];

  goto yynewstate;

yyerrlab:   /* here on detecting error */

  if (! yyerrstatus)
    /* If not already recovering from an error, report this error.  */
    {
      ++yynerrs;

#ifdef YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (yyn > YYFLAG && yyn < YYLAST)
	{
	  int size = 0;
	  char *msg;
	  int x, count;

	  count = 0;
	  /* Start X at -yyn if nec to avoid negative indexes in yycheck.  */
	  for (x = (yyn < 0 ? -yyn : 0);
	       x < (sizeof(yytname) / sizeof(char *)); x++)
	    if (yycheck[x + yyn] == x)
	      size += strlen(yytname[x]) + 15, count++;
	  msg = (char *) malloc(size + 15);
	  if (msg != 0)
	    {
	      strcpy(msg, "parse error");

	      if (count < 5)
		{
		  count = 0;
		  for (x = (yyn < 0 ? -yyn : 0);
		       x < (sizeof(yytname) / sizeof(char *)); x++)
		    if (yycheck[x + yyn] == x)
		      {
			strcat(msg, count == 0 ? ", expecting `" : " or `");
			strcat(msg, yytname[x]);
			strcat(msg, "'");
			count++;
		      }
		}
	      yyerror(msg);
	      free(msg);
	    }
	  else
	    yyerror ("parse error; also virtual memory exceeded");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror("parse error");
    }

  goto yyerrlab1;
yyerrlab1:   /* here on error raised explicitly by an action */

  if (yyerrstatus == 3)
    {
      /* if just tried and failed to reuse lookahead token after an error, discard it.  */

      /* return failure if at end of input */
      if (yychar == YYEOF)
	YYABORT;

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Discarding token %d (%s).\n", yychar, yytname[yychar1]);
#endif

      yychar = YYEMPTY;
    }

  /* Else will try to reuse lookahead token
     after shifting the error token.  */

  yyerrstatus = 3;		/* Each real token shifted decrements this */

  goto yyerrhandle;

yyerrdefault:  /* current state does not do anything special for the error token. */

#if 0
  /* This is wrong; only states that explicitly want error tokens
     should shift them.  */
  yyn = yydefact[yystate];  /* If its default is to accept any token, ok.  Otherwise pop it.*/
  if (yyn) goto yydefault;
#endif

yyerrpop:   /* pop the current state because it cannot handle the error token */

  if (yyssp == yyss) YYABORT;
  yyvsp--;
  yystate = *--yyssp;
#ifdef YYLSP_NEEDED
  yylsp--;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "Error: state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

yyerrhandle:

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yyerrdefault;

  yyn += YYTERROR;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != YYTERROR)
    goto yyerrdefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrpop;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrpop;

  if (yyn == YYFINAL)
    YYACCEPT;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting error token, ");
#endif

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  yystate = yyn;
  goto yynewstate;
}
#line 377 "parser.y"


yywrap()
{
}

yyerror(char *s)
{
	fail("Error de sintaxis", mk_simbolo(s));
}
