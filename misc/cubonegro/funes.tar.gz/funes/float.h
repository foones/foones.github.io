/* PROTOS */
RES *fu_float(float f);
RES *fu_float_sumar(RES *resto);
RES *fu_float_restar(RES *resto);
RES *fu_float_multiplicar(RES *resto);
RES *fu_float_dividir(RES *resto);
RES *fu_float_menor(RES *resto);
RES *fu_float_mayor(RES *resto);
RES *fu_float_elevar(RES *a, RES *b);
RES *fu_float_iguales(RES *resto);

/* MACROS */
#define VAL_FLOAT(R)	(*((float *) VAL(R)))
#define FLOAT_P(R)	(TIPO_P(tipo_float, R))
