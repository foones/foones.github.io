void fu_init_macro();
