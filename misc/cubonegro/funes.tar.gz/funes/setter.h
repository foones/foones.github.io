/* SETTERTABLE_SIZE deberia ser un primo */
#define SETTERTABLE_SIZE	211

RES *fu_setter(RES *accessor);
RES *fu_setter_set(RES *accessor, RES *setter);
