extern RES *Read_Sexpr;
extern RES *Std_Input;
extern RES *Std_Output;
extern RES *Std_Error;

/* PROTOS */
RES *fu_port(FILE *archivo);
RES *fu_reader(RES *cosa, unsigned char start);
RES *fu_read(RES *port);
RES *fu_stread(RES *cadena);
void fu_init_port();

/* MACROS */
#define VAL_PORT(RES)	((FILE *) VAL(RES))
#define VAL_READER(RES)	((YY_BUFFER_STATE) VAL(RES))
