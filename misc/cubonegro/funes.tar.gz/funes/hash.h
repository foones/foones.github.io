/* PROTOS */
RES *fu_make_hash(RES *len);
RES *fu_db(RES *args);

RES *fu_set_hash_f(RES *eqfun, RES *hashfun, RES *hash, RES *clave, RES *valor);
RES *fu_get_hash_f(RES *eqfun, RES *hashfun, RES *hash, RES *clave);

RES *fu_set_hash_eq(RES *hash, RES *clave, RES *valor);
RES *fu_get_hash_eq(RES *hash, RES *clave);

RES *fu_set_hash(RES *hash, RES *clave, RES *valor);
RES *fu_get_hash(RES *hash, RES *clave);

RES *fu_db_data(RES *hash, RES *func);
RES *fu_db_vec(RES *hash);

#define HASH_P(R)	(TIPO_P(tipo_vector, R) && (VECTOR_TIPO(VAL_VECTOR(R)) == vector_hash))
