#include "Fu.h"

RES* special_form_if;
RES* special_form_quote;
RES* special_form_fun;
RES* special_form_do;
RES* special_form_def;
RES* special_form_set;
RES* special_form_dyn;
RES* special_form_dir;
RES* special_form_while;
RES* special_form_or;
RES* special_form_not;
RES* special_form_eq;
RES* special_form_car;
RES* special_form_cdr;

#define SPECIAL_FORM(X)		{(X) = NEW(RES); TIPO(X) = tipo_special_form;}
#define BIND(SYMB, COSA)	fu_def_env(fu_symbol(SYMB), COSA)
void
fu_init_special()
{
	SPECIAL_FORM(special_form_quote);
	SPECIAL_FORM(special_form_if);
	SPECIAL_FORM(special_form_fun);
	SPECIAL_FORM(special_form_do);
	SPECIAL_FORM(special_form_def);
	SPECIAL_FORM(special_form_set);
	SPECIAL_FORM(special_form_dyn);
	SPECIAL_FORM(special_form_while);
	SPECIAL_FORM(special_form_or);

	BIND("quote", special_form_quote);
	BIND("if", special_form_if);
	BIND("fun", special_form_fun);
	BIND("do", special_form_do);
	BIND("def", special_form_def);
	BIND("set", special_form_set);
	BIND("dyn", special_form_dyn);
	BIND("while", special_form_while);
	BIND("or", special_form_or);

	/* para procedimientos inlined */
	SPECIAL_FORM(special_form_not);
	SPECIAL_FORM(special_form_eq);
	SPECIAL_FORM(special_form_car);
	SPECIAL_FORM(special_form_cdr);
	SPECIAL_FORM(special_form_dir);
}
#undef BIND
#undef SPECIAL_FORM
