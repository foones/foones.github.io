extern RES *special_form_if;
extern RES *special_form_fun;
extern RES *special_form_quote;
extern RES *special_form_do;
extern RES *special_form_def;
extern RES *special_form_set;
extern RES *special_form_dyn;
extern RES *special_form_while;
extern RES *special_form_or;
extern RES* special_form_dir;

/* para procedimientos inlined */
extern RES *special_form_not;
extern RES *special_form_eq;
extern RES *special_form_car;
extern RES *special_form_cdr;
