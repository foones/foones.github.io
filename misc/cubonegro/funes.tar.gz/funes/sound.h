RES *fu_sound(RES *f_freq, RES *f_duration, RES *f_rep, RES *f_delay);
