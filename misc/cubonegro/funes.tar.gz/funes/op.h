enum {
	NOP = 0,
	RET,
	CONST,
	PUSH,
	CONST_PUSH,
	APPLY,
	TAIL_APPLY,		/* apply para tail calls */
	JMP,
	JNF,
	JF,
	DEF,
	SET,
	GET,
	JMP_LABEL,		/* salta */
	JNF_LABEL,		/* salta si no NIL */
	JF_LABEL,		/* salta si NIL */
	LABEL,
	CLOSE,			/* cierra la closure en el entorno actual */
	PUSH_ENV,
	POP_ENV,
	ENV,
	SETTER,			/* obtiene el setter asociado a un accessor */
	NOT,
	EQ,
	OP_CAR,
	OP_CDR,
	PRINT,
};
