#include "Fu.h"

extern FILE *yyin;

RES *Read_Sexpr;
RES *Std_Input;
RES *Std_Output;
RES *Std_Error;

void
fu_init_port()
{
	Std_Input = fu_port(stdin);
	Std_Output = fu_port(stdout);
	Std_Error = fu_port(stderr);
}

RES *
fu_port(arch)
	FILE *arch;
{
	RES *p;
	p = NEW(RES);
	TIPO(p) = tipo_port;
	VAL(p) = (void *) arch;
	return p;
}
