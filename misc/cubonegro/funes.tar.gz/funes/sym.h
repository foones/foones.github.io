/* SYMTABLE_SIZE deberia ser un primo */
#define SYMTABLE_SIZE	211

void fu_init_symbol();
RES *fu_symbol(char *cadena);
RES *fu_keyword(char *cadena);
RES *fu_gensym();
RES *fu_mksym(RES *args);

#define VAL_SYMNAME(S)	((char *) VAL(S))
