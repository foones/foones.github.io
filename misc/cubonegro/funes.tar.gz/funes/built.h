void fu_init_builtins();
