#include "Fu.h"

RES *Sym_Table;

void
fu_init_symbol()
{
	Sym_Table = fu_make_hash(fu_int(SYMTABLE_SIZE));
}

RES *
fu_sym(s)
	char *s;
{
	RES *v;

	v = NEW(RES);
	TIPO(v) = tipo_sym;
	VAL(v) = (void *) s;
	return v;
}

RES *
fu_symbol(cadena)
	char *cadena;
{
	RES *resultado, *cad;

	cad = fu_str(cadena);
	resultado = fu_get_hash(Sym_Table, cad);
	if ( resultado == NIL ) 
		resultado = fu_set_hash(Sym_Table, cad, fu_sym(cadena));
	return CDR(resultado);
}

RES *
fu_keyword(cadena)
	char *cadena;
{
	RES *s;
	s = fu_symbol(cadena);
	TIPO(s) = tipo_keyword;
	return s;
}

RES *
fu_mksym(args)
	RES *args;
{
	return fu_symbol(VAL_STR(fu_mkstr(args)));
}

RES *
fu_gensym()
{
	static unsigned last_gensym = 0;
	char *s = "\0";

	s = NEWQ(char, (last_gensym % 10) + 5);
	sprintf(s, "#<G%i>\0", last_gensym++);
	return fu_sym(s);
}
